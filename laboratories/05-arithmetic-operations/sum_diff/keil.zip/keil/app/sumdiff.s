/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercise for sums and differences
 * --
 * -- Author(s):    <{muln,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.eabi_attribute 25, 1
.arch armv6-m
.cpu cortex-m0
.thumb
.type main, %function
.global main

// ------------------------------------------------------------------
// -- Symbolic Literals
// ------------------------------------------------------------------
.equ ADDR_DIP_SWITCH_7_0,   0x60000200
.equ ADDR_DIP_SWITCH_15_8,  0x60000201
.equ ADDR_LED_7_0,          0x60000100
.equ ADDR_LED_15_8,         0x60000101
.equ ADDR_LED_23_16,        0x60000102
.equ ADDR_LED_31_24,        0x60000103

// ------------------------------------------------------------------
// -- myCode
// ------------------------------------------------------------------
.section .text

main:

user_prog:
        // STUDENTS: To be programmed
        ldr     r2, =ADDR_DIP_SWITCH_15_8       // load high dip switches to R2 (Operand A)
        ldrb    r2, [r2]
        lsls    r2, r2, #24                     // shift input to most significant byte
        ldr     r3, =ADDR_DIP_SWITCH_7_0        // load low dip switches to R3 (Operand B)
        ldrb    r3, [r3]
        lsls    r3, r3, #24                     // shift input to most significant byte

        subs    r0, r2, r3
        mrs     r4, apsr                        // store Flags set by SUBS in R4
        lsrs    r4, r4, #24                     // shift flags to least significant byte

        adds    r1, r2, r3
        mrs     r5, apsr                        // store Flags set by ADDS in R5
        lsrs    r5, r5, #24                     // shift flags to least significant byte

        ldr     r2, =ADDR_LED_7_0               // write addition result to LED_L0_L7_ADDR
        lsrs    r1, r1, #24                     // shift result to least significant byte
        strb    r1, [r2]
        ldr     r2, =ADDR_LED_15_8              // write addition flags to LED_L8_L15_ADDR
        strb    r5, [r2]

        ldr     r2, =ADDR_LED_23_16             // write subtraction result to LED_L16_L23_ADDR
        lsrs    r0, r0, #24                     // shift result to least significant byte
        strb    r0, [r2]
        ldr     r2, =ADDR_LED_31_24             // write subtraction flags to LED_L24_L31_ADDR
        strb    r4, [r2]
        // END: To be programmed
        b       user_prog

        .balign 4
// ------------------------------------------------------------------
// End of code
// ------------------------------------------------------------------
        .end
