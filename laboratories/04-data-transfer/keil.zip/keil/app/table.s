/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercise to practice the use of arrays in
 * --               assembly
 * --
 * -- Author(s):    <{ruan,leiu,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.eabi_attribute 25, 1
.arch armv6-m
.cpu cortex-m0
.thumb
.type main, %function
.global main

// ------------------------------------------------------------------
// -- constants
// ------------------------------------------------------------------
.equ ADDR_LED_7_0,             0x60000100
.equ ADDR_LED_15_8,            0x60000101
.equ ADDR_LED_23_16,           0x60000102
.equ ADDR_LED_31_24,           0x60000103

.equ ADDR_DIP_SWITCH_7_0,      0x60000200
.equ ADDR_DIP_SWITCH_15_8,     0x60000201
.equ ADDR_DIP_SWITCH_31_24,    0x60000203

.equ ADDR_BUTTONS,             0x60000210

.equ BITMASK_KEY_T0,           0x01
.equ BITMASK_LOWER_NIBBLE,     0x0F

// ------------------------------------------------------------------
// -- Variables
// ------------------------------------------------------------------
.section .bss
// STUDENTS: To be programmed

// reserves 16 Bytes in Ram
byte_array:
    .space 16

// END: To be programmed
.balign 4

// ------------------------------------------------------------------
// -- myCode
// ------------------------------------------------------------------
.section .text
.balign 4

main:

readInput:
        bl      waitForKey                  // wait for key to be pressed and released

// STUDENTS: To be programmed
        ldr     r7, =ADDR_DIP_SWITCH_7_0    // read value
        ldrb    r0, [r7]
        ldr     r7, =ADDR_DIP_SWITCH_15_8   // read table index
        ldrb    r1, [r7]
        ldr     r7, =BITMASK_LOWER_NIBBLE   // load bitmask
        ands    r1, r1, r7                  // remove high nibble
        ldr     r7, =ADDR_LED_7_0           // write value to LED
        strb    r0, [r7]
        ldr     r7, =ADDR_LED_15_8          // write value to LED
        strb    r1, [r7]

storeTableElement:
        ldr     r7, =byte_array             // load base address table
        strb    r0, [r7, r1]                // store to base address + table index

readOutputIndex:
        ldr     r7, =ADDR_DIP_SWITCH_31_24  // read dip switch
        ldrb    r0, [r7]
        ldr     r6, =BITMASK_LOWER_NIBBLE   // load bitmask
        ands    r0, r6                      // remove unused upper bits

displayOutputIndex:
        ldr     r7, =ADDR_LED_31_24         // write dip switch value to led
        strb    r0, [r7]

displayTableValue:
        ldr     r7, =byte_array             // get value from table
        ldrb    r0, [r7, r0]

        ldr     r7, =ADDR_LED_23_16         // write to led
        strb    r0, [r7]

// END: To be programmed
        b       readInput
.balign 4

// ------------------------------------------------------------------
// Subroutines
// ------------------------------------------------------------------

// wait for key to be pressed and released
waitForKey:
        push    {r0, r1, r2}
        ldr     r1, =ADDR_BUTTONS           // load base address of keys
        ldr     r2, =BITMASK_KEY_T0         // load key mask T0

waitForPress:
        ldrb    r0, [r1]                    // load key values
        tst     r0, r2                      // check, if key T0 is pressed
        beq     waitForPress

waitForRelease:
        ldrb    r0, [r1]                    // load key values
        tst     r0, r2                      // check, if key T0 is released
        bne     waitForRelease

        pop     {r0, r1, r2}
        bx      lr
.balign 4

// ------------------------------------------------------------------
// End of code
// ------------------------------------------------------------------
.end

