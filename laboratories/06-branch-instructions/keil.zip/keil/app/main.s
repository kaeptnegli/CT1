/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercises for branch instructions
 * --
 * -- Author(s):    <{akdi,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.eabi_attribute 25, 1
.arch armv6-m
.cpu cortex-m0
.thumb
.type main, %function
.global main

// ------------------------------------------------------------------
// -- Address Defines
// ------------------------------------------------------------------

.equ ADDR_LED_15_0,         0x60000100
.equ ADDR_LED_31_16,        0x60000102
.equ ADDR_DIP_SWITCH_7_0,   0x60000200
.equ ADDR_DIP_SWITCH_15_8,  0x60000201
.equ ADDR_7_SEG_BIN_DS3_0,  0x60000114
.equ ADDR_BUTTONS,          0x60000210

.equ ADDR_LCD_RED,          0x60000340
.equ ADDR_LCD_GREEN,        0x60000342
.equ ADDR_LCD_BLUE,         0x60000344
.equ LCD_BACKLIGHT_FULL,    0xffff
.equ LCD_BACKLIGHT_OFF,     0x0000

// ------------------------------------------------------------------
// -- myCode
// ------------------------------------------------------------------
.section .text

main:
        movs    r6, #0xFF                   // load a pathological value
        movs    r7, #0                      // reset register

main_loop:
// STUDENTS: To be programmed
        ldr     r0, =ADDR_DIP_SWITCH_7_0
        ldrb    r1, [r0]                    // 1s in R1
        ldr     r0, =ADDR_DIP_SWITCH_15_8
        ldrb    r2, [r0]                    // 10s in R2
        movs    r0, #0x0F
        ands    r1, r0                      // mask least significant 4 switches
        ands    r2, r0

// (optional) check if bcd is valid
check_bcd:
        cmp     r1, #10                     // test 1s for valid bcd
        bhs     bcd_is_invalid              // jump if no bcd
        cmp     r2, #10                     // test 10s for valid bcd
        bhs     bcd_is_invalid              // jump if no bcd
        bl      display_bcd

// (optional) bcd is not valid
bcd_is_invalid:
        movs    r1, #0                      // set zero, if not a valid bcd
        movs    r2, #0

display_bcd:
        lsls    r3, r2, #4
        orrs    r3, r1
        ldr     r0, =ADDR_LED_15_0
        strb    r3, [r0]
        ldr     r0, =ADDR_7_SEG_BIN_DS3_0
        strb    r3, [r0]

read_t0:
        ldr     r0, =ADDR_BUTTONS
        ldrb    r3, [r0]
        movs    r4, #0x01
        tst     r3, r4
        bne     manual_multiplication

mul_instruction:
        ldr     r3, =ADDR_LCD_RED           // reset red channel of lcd
        ldr     r4, =LCD_BACKLIGHT_OFF
        strh    r4, [r3]
        ldr     r3, =ADDR_LCD_BLUE          // set blue channel of lcd
        ldr     r4, =LCD_BACKLIGHT_FULL
        strh    r4, [r3]

        movs    r0, #10
        muls    r2, r0                      // multiply tens by ten
        add     r2, r1                      // add tens and ones
        bl      multiplication_done

manual_multiplication:
        ldr     r3, =ADDR_LCD_BLUE          // reset blue channel of lcd
        ldr     r4, =LCD_BACKLIGHT_OFF
        strh    r4, [r3]
        ldr     r3, =ADDR_LCD_RED           // set red channel of lcd
        ldr     r4, =LCD_BACKLIGHT_FULL
        strh    r4, [r3]

        lsls    r0, r2, #1                  // multiply tens by two
        lsls    r2, #3                      // multiply tens by eight
        add     r2, r0
        add     r2, r1                      // add tens and ones

multiplication_done:
        ldr     r0, =ADDR_LED_15_0          // write binary result to led
        strb    r2, [r0, #1]

        ldr     r0, =ADDR_7_SEG_BIN_DS3_0   // write binary result to 7seg
        str     r2, [r0]

count_active_leds:
        ldr     r1, =0                      // reset counter register
        movs    r0, #1

count_loop:
        // shift right (sets carry flag if lsb = 1)
        lsrs    r2, #1

        // skip counting if carry flag = 0
        bcc     skip_count

        // increase counter if carry set
        // IMPORTANT: use `add` to not update status flags
        add     r1, r0

skip_count:
        // loop while input != 0
        // only works because flags from the right shift were kept!
        bne     count_loop

prepare_light_bar:
        // skip generation of light bar, if its length has not changed
        cmp     r1, r6
        beq     chasing_light
        movs    r6, r1

        // generate bar of ones with counted length
        movs    r2, #1
        lsls    r2, r1
        subs    r2, #1
        // rotate bar to the left side
        rors    r2, r1

        // generate an alias for the more significant two bytes
        lsrs    r7, r2, #16
        orrs    r7, r2

chasing_light:
        // rotate by one to the left
        ldr     r0, =ADDR_LED_31_16
        strh    r7, [r0]
        movs    r0, #1
        rors    r7, r0

        bl      pause

// END: To be programmed

        b       main_loop

//----------------------------------------------------
// Subroutines
//----------------------------------------------------

// pause for disco_lights
.type pause, %function
pause:
        push    {r0, r1}
        movs    r1, #1
        ldr     r0, =0x00300000

loop:
        subs    r0, r1
        bcs     loop

        pop     {r0, r1}
        bx      lr

        .balign 4

// ------------------------------------------------------------------
// End of code
// ------------------------------------------------------------------
        .end
