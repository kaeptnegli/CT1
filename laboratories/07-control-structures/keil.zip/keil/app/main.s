/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  laboratory on switch/case in assembly
 * --
 * -- Author(s):    <{kesr,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.eabi_attribute 25, 1
.arch armv6-m
.cpu cortex-m0
.thumb
.type main, %function
.global main

// ------------------------------------------------------------------
// -- constants
// ------------------------------------------------------------------
.equ ADDR_LED_15_0,           0x60000100
.equ ADDR_LED_31_16,          0x60000102
.equ ADDR_7_SEG_BIN_DS1_0,    0x60000114
.equ ADDR_DIP_SWITCH_15_0,    0x60000200
.equ ADDR_HEX_SWITCH,         0x60000211

.equ NR_CASES,                0xB


// ------------------------------------------------------------------
// -- Variables
// ------------------------------------------------------------------
.section .rodata
.balign 4

jump_table:
/*
 * NOTE: Least significant bit determines the instruction set after a
 * jump. The directive `.thumb` at the beginning of the file tells the
 * assembler, that this file should be translated into thumb
 * instructions. Unfortunately the GNU assembler only regards this
 * option for instructions, not labels. Thus one needs to tell the
 * assembler explicitly to translate labels into thumb mode (LSB = 1).
 * This is done with the directive `.thumb_func` which affects just
 * the next symbol.
 *
 * Alternatively one can manually add one to the label:
 * ```AS
 * .word case_add + 1
 * .word case_sub + 1
 * ```
 */

.thumb_func
    .word   case_dark

// STUDENTS: To be programmed
; .thumb_func
    .word   case_add

; .thumb_func
    .word   case_sub

; .thumb_func
    .word   case_mul

; .thumb_func
    .word   case_and

; .thumb_func
    .word   case_or

; .thumb_func
    .word   case_xor

; .thumb_func
    .word   case_not

; .thumb_func
    .word   case_nand

; .thumb_func
    .word   case_nor

; .thumb_func
    .word   case_xnor

// END: To be programmed

// ------------------------------------------------------------------
// -- myCode
// ------------------------------------------------------------------
.section .text
.balign 4

main:

// -------------------------------------------------------------------
// -- Main
// -------------------------------------------------------------------

read_dipsw:
    // STUDENTS: To be programmed
    ldr  r7, =ADDR_DIP_SWITCH_15_0
    ldrh r0, [r7]
    ldr  r7, =ADDR_LED_15_0
    strh r0, [r7]
    lsrs r1, r0, #8
    uxtb r0, r0
    // END: To be programmed

read_hexsw:                         // read operation into r2 and display on 7seg.
    // STUDENTS: To be programmed
    ldr  r7, =ADDR_HEX_SWITCH
    ldrb r2, [r7]                   // read operation selector
    movs r7, #0xF                   // remove upper half byte
    ands r2, r2, r7
    ldr  r7, =ADDR_7_SEG_BIN_DS1_0  // display on 7 segment
    strh r2, [r7]
    // END: To be programmed

case_switch:                        // implement switch statement as shown on lecture slide
    // STUDENTS: To be programmed
    cmp  r2, #NR_CASES              // if hexsw value out of case
    bhs  case_default               // ..jump to case_default

    lsls r2, #2
    ldr  r7, =jump_table
    ldr  r7, [r7, r2]               // load address of operation
    bx   r7                         // jump to operation
    // END: To be programmed


    // add the code for the individual cases below
    // - operand 1 in r0
    // - operand 2 in r1
    // - result in r0

.thumb_func
case_dark:
    movs r0, #0
    b    display_result

.thumb_func
case_add:
    adds r0, r0, r1
    b    display_result

    // STUDENTS: To be programmed

    // -- arithmetic operations

.thumb_func
case_sub:
    subs r0, r0, r1
    b    display_result

.thumb_func
case_mul:
    muls r0, r1, r0
    b    display_result

    // -- logical operations

.thumb_func
case_and:
    ands r0, r0, r1
    b    display_result

.thumb_func
case_or:
    orrs r0, r0, r1
    b    display_result

.thumb_func
case_xor:
    eors r0, r0, r1
    b    display_result

.thumb_func
case_not:
    mvns r0, r0
    b    display_result

.thumb_func
case_nand:
    ands r0, r0, r1
    mvns r0, r0
    b    display_result

.thumb_func
case_nor:
    orrs r0, r0, r1
    mvns r0, r0
    b    display_result

.thumb_func
case_xnor:
    eors r0, r0, r1
    mvns r0, r0
    b    display_result

    // -- other operations

.thumb_func
case_default:
    ldr  r0, =0xFFFF
    b    display_result

    // END: To be programmed


display_result:  // Display result on LEDs
    // STUDENTS: To be programmed
    ldr  r7, =ADDR_LED_31_16
    strh r0, [r7]                   // display result on led
    // END: To be programmed

    b    read_dipsw

    // -------------------------------------------------------------------
    // -- End of file
    // -------------------------------------------------------------------
    .end

