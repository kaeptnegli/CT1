/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercise for subroutines and parameter passing
 * --
 * -- Author(s):    <{muln,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

#include <stdint.h>

// STUDENTS: To be programmed
#define ADDR_DIP_SWITCH_31_0    0x60000200
#define ADDR_LED_31_0           0x60000100

extern void write_word(uint32_t out_address, uint32_t out_value);
extern uint32_t read_word(uint32_t in_address);

int main(void)
{
    while (1) {
        uint32_t value = read_word(ADDR_DIP_SWITCH_31_0);
        write_word(ADDR_LED_31_0, value);
    }
}
// END: To be programmed
