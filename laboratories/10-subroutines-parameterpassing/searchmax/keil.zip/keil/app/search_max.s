/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  search maximum value in a table
 * --
 * -- Author(s):    <{muln,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.arch armv6-m
.cpu cortex-m0
.eabi_attribute 25, 1
.thumb

// -------------------------------------------------------------------
// -- Exports
// -------------------------------------------------------------------
.global search_max

// -------------------------------------------------------------------
// -- Defines
// -------------------------------------------------------------------
// STUDENTS: To be programmed
.equ TABLE_LENGTH_0,    0x80000000
// END: To be programmed


.section .text

// Searchmax
// - tableaddress in R0
// - table length in R1
// - result returned in R0
.type search_max, %function
search_max:
                // STUDENTS: To be programmed
                push    {r7, lr}
                movs    r7, r0                  // Move table address to R7
                ldr     r0, =TABLE_LENGTH_0     // set empty table value as default
                ldr     r2, =1                  // Set up counter
                cmp     r1, #0x00               // check table length
                beq     end_search
                ldr     r0, [r7]                // load first tablelement

next_element:
                cmp     r1, r2                  // check if finished
                ble     end_search
                adds    r2, r2, #1              // increment counter
                adds    r7, r7, #4              // calculate address next table element
                ldr     r3, [r7]                // load table element
                cmp     r0, r3                  // compare new element ,with prev. max
                bgt     next_element
                movs    r0, r3                  // if greater save to R0
                b       next_element

end_search:
                pop     {r7, pc}                // Return to caller
                // END: To be programmed
                .balign 4

// -------------------------------------------------------------------
// -- End of file
// -------------------------------------------------------------------
                .end

