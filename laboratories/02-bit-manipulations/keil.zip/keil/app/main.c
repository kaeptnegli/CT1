/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  laboratory to examine bit manipulations
 * --
 * -- Author(s):    <{ruan}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

#include "utils_ctboard.h"

#define ADDR_DIP_SWITCH_31_0 ((uint32_t) 0x60000200)
#define ADDR_DIP_SWITCH_7_0  ((uint32_t) 0x60000200)
#define ADDR_LED_31_24       ((uint32_t) 0x60000103)
#define ADDR_LED_23_16       ((uint32_t) 0x60000102)
#define ADDR_LED_15_8        ((uint32_t) 0x60000101)
#define ADDR_LED_7_0         ((uint32_t) 0x60000100)
#define ADDR_BUTTONS         ((uint32_t) 0x60000210)

// define your own macros for bitmasks below (#define)
/// STUDENTS: To be programmed
#define BITMASK_LEDS_ON  ((uint8_t) 0xC0)
#define BITMASK_LEDS_OFF ((uint8_t) 0x30)
#define BITMASK_KEY_0    ((uint8_t) 0x01)
#define BITMASK_KEY_1    ((uint8_t) 0x02)
#define BITMASK_KEY_2    ((uint8_t) 0x04)
#define BITMASK_KEY_3    ((uint8_t) 0x08)
#define BITMASK_KEY_ALL  ((uint8_t) 0x0F)
/// END: To be programmed

int main(void)
{
    uint8_t led_value = 0;

    // add variables below
    /// STUDENTS: To be programmed
    uint8_t key_down_counter = 0x0;
    uint8_t key_stroke_counter = 0x0;
    uint8_t keys_value = 0x0;
    uint8_t previous_keys_value = 0x0;
    uint8_t keys_pressed;
    uint8_t output_value = 0;
    /// END: To be programmed

    while (1) {
        // ---------- Task 3.1 ----------
        led_value = read_byte(ADDR_DIP_SWITCH_7_0);

        /// STUDENTS: To be programmed
        // apply bitmasks
        led_value &= (uint8_t) ~BITMASK_LEDS_OFF;
        led_value |= BITMASK_LEDS_ON;
        /// END: To be programmed

        write_byte(ADDR_LED_7_0, led_value);

        // ---------- Task 3.2 and 3.3 ----------
        /// STUDENTS: To be programmed
        keys_value = read_byte(ADDR_BUTTONS) & BITMASK_KEY_ALL;

        // count and display how many times T0 is low??
        if (keys_value & BITMASK_KEY_0) {
            key_down_counter++;
        }
        write_byte(ADDR_LED_15_8, key_down_counter);

        // detect rising edges on all buttons
        keys_pressed = ~previous_keys_value & keys_value;
        previous_keys_value = keys_value;

        // count and display how many times T0 is pressed
        if (keys_pressed & BITMASK_KEY_0) {
            key_stroke_counter++;
        }
        write_byte(ADDR_LED_31_24, key_stroke_counter);

        // ---------- Task 3 ----------
        // manipulate the output_value depending on the pressed button
        if (keys_pressed & BITMASK_KEY_0) {
            output_value >>= 1;
        }else if (keys_pressed & BITMASK_KEY_1) {
            output_value <<= 1;
        }else if (keys_pressed & BITMASK_KEY_2) {
            output_value = ~output_value;
        }else if (keys_pressed & BITMASK_KEY_3) {
            output_value = read_byte(ADDR_DIP_SWITCH_7_0);
        }

        write_byte(ADDR_LED_23_16, output_value);

        /// END: To be programmed
    }
}
