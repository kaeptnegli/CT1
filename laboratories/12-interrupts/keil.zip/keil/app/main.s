/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercise for interrupts
 * --
 * -- Author(s):    <{akdi,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.arch armv6-m
.cpu cortex-m0
.eabi_attribute 25, 1
.thumb

// -----------------------------------------------------------------------------
// -- Exports
// -----------------------------------------------------------------------------
.global main
.global EXTI0_IRQHandler
.global TIM2_IRQHandler

// -----------------------------------------------------------------------------
// -- Constants
// -----------------------------------------------------------------------------
.equ ADDR_LED_15_0,     0x60000100
.equ ADDR_LED_16_31,    0x60000102
.equ ADDR_7SEG,         0x60000114
.equ ADDR_SETENA0,      0xE000E100

// -----------------------------------------------------------------------------
// -- Variables
// -----------------------------------------------------------------------------
.section .data

// STUDENTS: To be programmed
var_counter:
    .word               0x00000000
var_speed:
    .word               0x00000000
// END: To be programmed


// -----------------------------------------------------------------------------
// -- Main
// -----------------------------------------------------------------------------
.section .text

.type main, %function
main:
        bl      init_measurement

        // Configure NVIC (enable interrupt channel)
        // STUDENTS: To be programmed
        ldr     r0, =ADDR_SETENA0
        ldr     r7, =0x10000040        // Enable EXTI0 and TIM2 interrupts
        str     r7, [r0]
        // END: To be programmed

        // Initialize variables
        // STUDENTS: To be programmed
        ldr     r1, =var_counter
        movs    r7, #0
        str     r7, [r1]

        ldr     r2, =var_speed
        str     r7, [r2]

        // END: To be programmed

loop:
        // Output counter on 7-seg
        // STUDENTS: To be programmed

disp_counter:
        ldr     r7, =var_speed
        ldr     r2, =ADDR_7SEG
        ldrh    r6, [r7]
        strh    r6, [r2]

        // END: To be programmed

        b       loop

        .balign 4


// -----------------------------------------------------------------------------
// Handler for EXTI0 interrupt
// -----------------------------------------------------------------------------
        // STUDENTS: To be programmed
.type EXTI0_IRQHandler, %function
EXTI0_IRQHandler:
        push    {lr}

        ldr     r0, =var_counter

        // Critical section - disable all interrupts
        //CPSID i
        ldr     r1, [r0]
        adds    r1, r1, #1             // Increment counter
        str     r1, [r0]
        // Critical section end - enable all interrupts
        //CPSIE i

        bl      clear_IRQ_EXTI0

        pop     {pc}

        // END: To be programmed
        .balign 4

// -----------------------------------------------------------------------------
// Handler for TIM2 interrupt
// -----------------------------------------------------------------------------
        // STUDENTS: To be programmed

.type TIM2_IRQHandler, %function
TIM2_IRQHandler:
        push    {lr}

        ldr     r0, =var_counter
        ldr     r1, =var_speed
        movs    r2, #0
        // Critical section - disable all interrupts
        //CPSID i
        ldr     r3, [r0]               // Load var_counter
        str     r2, [r0]               // Reset var_counter
        // Critical section end - enable all interrupts
        //CPSIE i
        str     r3, [r1]               // Save var_speed

        ldr     r0, =ADDR_LED_16_31
        ldrh    r1, [r0]
        mvns    r1, r1                 // Invert pattern -> show clock
        strh    r1, [r0]

        bl      clear_IRQ_TIM2

        pop     {pc}

        // END: To be programmed
        .balign 4

// -----------------------------------------------------------------------------
// -- End of file
// -----------------------------------------------------------------------------
        .end
