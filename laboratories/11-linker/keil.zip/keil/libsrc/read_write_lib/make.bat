@echo off

set TOOLROOT=C:\Keil_v5\ARM
set ARMCC=%TOOLROOT%\ARMCC\bin\ArmCC
set CCARGS=-c --cpu Cortex-M0 -D__EVAL --apcs=interwork
set CCINC=-I..\..\inc
set ARMAR=%TOOLROOT%\ARMCC\bin\ArmAR
if not exist obj; md obj

del /F /Q obj\*.o

set ARCHIVE=read_write

@echo on
%ARMCC% %CCARGS% %CCINC% -O3 -o obj\read.o   read.c
%ARMCC% %CCARGS% %CCINC% -O3 -o obj\write.o  write.c

%ARMAR% -r obj\%ARCHIVE%.lib obj\*.o
del /F /Q obj\*.o

%ARMCC% %CCARGS% %CCINC% -g -o obj\read.o   read.c
%ARMCC% %CCARGS% %CCINC% -g -o obj\write.o  write.c

%ARMAR% -r obj\%ARCHIVE%_debug.lib obj\*.o
del /F /Q obj\*.o

copy obj\%ARCHIVE%.lib       ..\..\lib\%ARCHIVE%.lib
copy obj\%ARCHIVE%_debug.lib ..\..\lib_debug\%ARCHIVE%.lib
copy obj\%ARCHIVE%_debug.lib ..\..\lib_debug_with_src\%ARCHIVE%.lib
copy *.c                     ..\..\lib_debug_with_src\*.c

rmdir /S /Q obj
