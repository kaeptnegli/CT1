/* ------------------------------------------------------------------
 * --  _____       ______  _____
 * -- |_   _|     |  ____|/ ____|
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems
 * --   | | | '_ \|  __|  \___ \   Zurich University of
 * --  _| |_| | | | |____ ____) |  Applied Sciences
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland
 * --
 * -- Description:  exercises for modular programming
 * --
 * -- Author(s):    <{kesr,scbj}@zhaw.ch>
 * --
 * ------------------------------------------------------------------
 */

.syntax unified
.eabi_attribute 25, 1
.arch armv6-m
.cpu cortex-m0
.thumb
.type main, %function
.global main

// ------------------------------------------------------------------
// -- defines
// ------------------------------------------------------------------
.equ ADDR_DIP_SWITCHES,         0x60000200
.equ ADDR_BUTTONS,              0x60000210
.equ ADDR_LED_31_0,             0x60000100
.equ ADDR_7SEG,                 0x60000114
.equ ADDR_LCD_COLOUR,           0x60000340
.equ ADDR_LCD_ASCII,            0x60000300
.equ ADDR_LCD_ASCII_BIT_POS,    0x60000302
.equ ADDR_LCD_ASCII_2ND_LINE,   0x60000314

// value for clearing lcd
.equ ASCII_DIGIT_CLEAR,         0x00000000
.equ LCD_LAST_OFFSET,           0x00000028

// offset for showing the digit in the lcd
.equ ASCII_DIGIT_OFFSET,        0x00000030

// lcd background colors to be written
.equ LCD_RED,                   0
.equ LCD_GREEN,                 2
.equ LCD_BLUE,                  4

// ------------------------------ = ---------------------------------
// -- symbol import
// ------------------------------------------------------------------
.global adc_init
.global adc_get_value

// ------------------------------------------------------------------
// -- symbol export
// ------------------------------------------------------------------
.global main

// ------------------------------------------------------------------
// -- constant declarations
// ------------------------------------------------------------------
.section .rodata
DISPLAY_BIT:    .string     "Bit "
DISPLAY_2_BIT:  .string     "2"
DISPLAY_4_BIT:  .string     "4"
DISPLAY_8_BIT:  .string     "8"

.balign 4

// ------------------------------------------------------------------
// -- code
// ------------------------------------------------------------------
.section .text

.type main, %function
main:
        bl          adc_init
        bl          clear_lcd

main_loop:
// STUDENTS: To be programmed

        bl          adc_get_value
        movs        r7, r0

        ldr         r0, =ADDR_BUTTONS
        ldrb        r0, [r0]                        // get t0 value
        movs        r1, #1
        tst         r0, r1                          // bit in carry
        beq         red_blue

green:
        // set background color
        ldr         r1, =ADDR_LCD_COLOUR
        ldr         r0, =0x0000
        strh        r0, [r1, #LCD_RED]
        strh        r0, [r1, #LCD_BLUE]
        ldr         r0, =0xFFFF
        strh        r0, [r1, #LCD_GREEN]
        // write 7 segment
        ldr         r1, =ADDR_7SEG
        strh        r7, [r1]

led_bar:
        // calculate led bar from adc value
        movs        r0, #1
        lsrs        r1, r7, #3                      // #leds = (value / 8)
        adds        r1, #1
        lsls        r0, r0, r1                      // (1 << #leds + 1)
        subs        r0, #1                          // led bar = (1 << #leds + 1) - 1

display_led_bar:
        ldr         r1, =ADDR_LED_31_0
        str         r0, [r1]

        b           main_loop

red_blue:
        ldr         r0, =ADDR_LED_31_0
        movs        r1, #0
        str         r1, [r0]
        // read switches and subtract adc value -> r5
        ldr         r0, =ADDR_DIP_SWITCHES
        ldrb        r0, [r0]
        subs        r7, r0, r7
        // output dec value to 7seg
        ldr         r0, =ADDR_7SEG
        strh        r7, [r0]
        // check if difference is smaller than 0
        bmi         red

blue:
        // set background color
        ldr         r1, =ADDR_LCD_COLOUR
        ldr         r0, =0x0000
        strh        r0, [r1, #LCD_RED]
        strh        r0, [r1, #LCD_GREEN]
        ldr         r0, =0xFFFF
        strh        r0, [r1, #LCD_BLUE]

check_2_bits:
        cmp         r7, #4
        bpl         check_4_bits
        ldr         r1, =DISPLAY_2_BIT
        ldrb        r1, [r1]
        b           write_num_bits

check_4_bits:
        cmp         r7, #16
        bpl         else_8_bits
        ldr         r1, =DISPLAY_4_BIT
        ldrb        r1, [r1]
        b           write_num_bits

else_8_bits:
        ldr         r1, =DISPLAY_8_BIT
        ldrb        r1, [r1]
        strb        r1, [r0]

write_num_bits:
        ldr         r0, =ADDR_LCD_ASCII
        strb        r1, [r0]
        bl          write_bit_ascii
        b           main_loop

red:
        // set background color
        ldr         r1, =ADDR_LCD_COLOUR
        ldr         r0, =0x0000
        strh        r0, [r1, #LCD_GREEN]
        strh        r0, [r1, #LCD_BLUE]
        ldr         r0, =0xFFFF
        strh        r0, [r1, #LCD_RED]

        // prepare for counting zeroes
        movs        r0, #0xFF
        ands        r7, r0
        movs        r0, #0                          // reset zero counter
        movs        r2, #1

        // NOTE: we count the ones instead of the
        // zeroes, because it is easier, and then
        // subtract the result from 8 to get the
        // number of zeroes.
        // this takes a few steps before and after
        // the loop but requires less variables to
        // keep track of.

count_ones:
        lsrs        r7, #1
        bcc         zero_detected
        add         r0, r2
zero_detected:
        bne         count_ones

calculate_zeroes:
        movs        r1, #8
        subs        r0, r1, r0

display_zeroes:
        ldr         r1, =ADDR_LCD_ASCII_2ND_LINE
        ldr         r2, =ASCII_DIGIT_OFFSET
        adds        r0, r0, r2                      // ascii value in r2
        strh        r0, [r1]

// END: To be programmed
        b           main_loop

.type clear_lcd, %function
clear_lcd:
        push        {r0, r1, r2}
        ldr         r0, =ADDR_LCD_ASCII
        ldr         r1, =LCD_LAST_OFFSET
        ldr         r2, =ASCII_DIGIT_CLEAR

clear_lcd_loop:
        subs        r1, #4                          // decrease offset
        str         r2, [r0, r1]                    // reset character
        bgt         clear_lcd_loop                  // loop if (offset > 0)
        pop         {r0, r1, r2}
        bx          lr

.type clear_lcd, %function
write_bit_ascii:
        push        {r0, r1}
        ldr         r0, =ADDR_LCD_ASCII_BIT_POS
        ldr         r1, =DISPLAY_BIT
        ldr         r1, [r1]
        str         r1, [r0]
        pop         {r0, r1}
        bx          lr

.balign 4
.end
